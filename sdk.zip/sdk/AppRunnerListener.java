package com.mq;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
@Component
public class AppRunnerListener implements CommandLineRunner {

    @Override
    public void run(String... strings) throws Exception {
        RabbitMQConsumer consumer = RabbitMQFactory.consumer("test", (exchangeName, routingKey, queueName, o) -> {
            System.out.println(new String((byte[]) o));
            return true;
        });
        consumer.start();
        RabbitMQConsumer c = RabbitMQFactory.consumer("qqq", (exchangeName, routingKey, queueName, o) -> {
            System.out.println("1"+new String((byte[]) o));
            return true;
        });
        c.start();
    }
}
