package com.mq;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Created by Gao.WenLong on 2019/9/9.
 */
@Api("测试接口")
@org.springframework.web.bind.annotation.RestController
public class RestController {

    @ApiOperation("测试")
    @RequestMapping(value="/test",method = RequestMethod.GET)
    public String test() {
        return "aaa";
    }

}
