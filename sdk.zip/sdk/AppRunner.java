package com.mq;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
@Component
public class AppRunner implements CommandLineRunner {

    @Override
    public void run(String... strings) throws Exception {
        RabbitMQProducer producer = RabbitMQFactory.fanoutProducer("test","test");
        RabbitMQProducer p = RabbitMQFactory.directProducer("direct","ddd","qqq");
        RabbitMQProducer s = RabbitMQFactory.directProducer("direct1","ddd","qqq");

        producer.publish("String");
        p.publish("ddd","ssss");
        s.publish("ddd","123");
    }
}
