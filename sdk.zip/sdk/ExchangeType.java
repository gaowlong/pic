package com.mq;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
public interface ExchangeType {
    String FANOUT = "fanout";

    String DIRECT = "direct";

    String TOPIC = "topic";

}
