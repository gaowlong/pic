package com.mq;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
public class RabbitMQBinder {

    private RabbitAdmin rabbitAdmin;

    public RabbitMQBinder(ConnectionFactory connectionFactory) {
        this.rabbitAdmin = new RabbitAdmin(connectionFactory);
    }

    public void binding(String exchangeName,String routingKey,String queueName,String exchangeType) {
        Queue queue = new Queue(queueName);
        //绑定rabbitAdmin，防止创建队列时不同的vhost都创建一份
        queue.setAdminsThatShouldDeclare(new Object[]{this.rabbitAdmin});
        rabbitAdmin.declareQueue(queue);
        switch (exchangeType) {
            case ExchangeType.DIRECT:
                DirectExchange directExchange = new DirectExchange(exchangeName);
                rabbitAdmin.declareExchange(directExchange);
                rabbitAdmin.declareBinding(BindingBuilder.bind(queue).to(directExchange).with(routingKey));
                break;
            case ExchangeType.TOPIC:
                TopicExchange topicExchange = new TopicExchange(exchangeName);
                rabbitAdmin.declareExchange(topicExchange);
                rabbitAdmin.declareBinding(BindingBuilder.bind(queue).to(topicExchange).with(routingKey));
                break;
            case ExchangeType.FANOUT:
                FanoutExchange fanoutExchange = new FanoutExchange(exchangeName);
                rabbitAdmin.declareExchange(fanoutExchange);
                rabbitAdmin.declareBinding(BindingBuilder.bind(queue).to(fanoutExchange));
                break;
             default:
                 throw new IllegalArgumentException("不支持的exchangeType-"+exchangeName);
        }
    }
}
