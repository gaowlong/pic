package com.mq;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
public interface RabbitMQListener<T> {

    boolean onMessage(String exchangeName,String routingKey,String queueName,T t);

}
