package com.mq;

import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.listener.api.ChannelAwareMessageListener;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
public class SimpleRabbitMQListener implements ChannelAwareMessageListener {

    private RabbitMQListener rabbitMQListener;

    public SimpleRabbitMQListener(RabbitMQListener rabbitMQListener) {
        this.rabbitMQListener = rabbitMQListener;
    }

    @Override
    public void onMessage(Message message, Channel channel) throws Exception {
        String exchangeName = message.getMessageProperties().getReceivedExchange();
        String queueName = message.getMessageProperties().getConsumerQueue();
        String routingKey = message.getMessageProperties().getReceivedRoutingKey();
        long tag = message.getMessageProperties().getDeliveryTag();
        try {
            boolean b = this.rabbitMQListener.onMessage(exchangeName, routingKey, queueName, message.getBody());
            if(b) {
                channel.basicAck(tag,false);
            }else {
                channel.basicNack(tag,false,true);
            }
        }catch (Exception e) {
            channel.basicNack(tag,false,true);
        }
    }
}
