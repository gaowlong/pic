package com.mq;

import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
public class RabbitMQConsumer {

    private SimpleMessageListenerContainer container;
    private ConnectionFactory connectionFactory;
    private RabbitAdmin rabbitAdmin;
    private String queueName;
    private String exchangeName;
    private RabbitMQListener rabbitMQListener;

    public RabbitMQConsumer(ConnectionFactory connectionFactory, String queueName, RabbitMQListener rabbitMQListener) {
        this.connectionFactory = connectionFactory;
        this.queueName = queueName;
        this.rabbitAdmin = new RabbitAdmin(connectionFactory);
        this.rabbitMQListener = rabbitMQListener;
    }

    public void start() {
        this.container = new SimpleMessageListenerContainer();
        this.container.setConnectionFactory(this.connectionFactory);
        Queue queue = new Queue(this.queueName);
        queue.setAdminsThatShouldDeclare(new Object[]{this.rabbitAdmin});
        this.rabbitAdmin.declareQueue(queue);
        this.container.addQueueNames(new String[]{queueName});
        if(rabbitMQListener != null) {
            this.container.setMessageListener(new SimpleRabbitMQListener(this.rabbitMQListener));
        }
        //是否自动设置应答MANUAL-手动,AUTO-自动(无异常自动应答),NONE-无ACK机制
        this.container.setAcknowledgeMode(AcknowledgeMode.MANUAL);
        this.container.start();
    }

    public void stop() {
        if(this.isRuning()) {
            this.container.stop();
        }
    }

    public boolean isRuning() {
        return this.container !=null && this.container.isRunning();
    }
}
