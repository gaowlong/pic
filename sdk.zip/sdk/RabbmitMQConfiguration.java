package com.mq;

import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
@Configuration
public class RabbmitMQConfiguration {

    @Value("${spring.rabbitmq.addresses:}")
    private String address ;
    @Value("${spring.rabbitmq.username:}")
    private String username;
    @Value("${spring.rabbitmq.password:}")
    private String password;
    @Value("${spring.rabbitmq.virtual-host:/}")
    private String virtualHost;

    @Bean
    public CachingConnectionFactory cachingConnectionFactory() {
        CachingConnectionFactory factory = new CachingConnectionFactory();
        factory.setVirtualHost(virtualHost);
        factory.setPassword(password);
        factory.setUsername(username);
        factory.setAddresses(address);
        return factory;
    }

    @Bean
    public RabbitMQFactory rabbitMQFactory(CachingConnectionFactory cachingConnectionFactory) {
        return new RabbitMQFactory(cachingConnectionFactory);
    }

}
