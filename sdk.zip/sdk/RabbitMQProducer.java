package com.mq;

import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
public class RabbitMQProducer {

    private ConnectionFactory connectionFactory;
    private RabbitTemplate rabbitTemplate;
    private String exchangeName;
    private String routingKey;
    private String queueName;
    private String exchangeType;
    private RabbitMQBinder binder;

    public RabbitMQProducer(ConnectionFactory connectionFactory, String exchangeName, String routingKey, String queueName, String exchangeType) {
        this.connectionFactory = connectionFactory;
        this.rabbitTemplate = new RabbitTemplate(connectionFactory);
        this.exchangeName = exchangeName;
        this.routingKey = routingKey;
        this.queueName = queueName;
        this.exchangeType = exchangeType;
        //true-没有匹配队列返回给生产者，false-直接丢弃
        this.rabbitTemplate.setMandatory(true);
    }

    public void build() {
        if(StringUtils.isNotBlank(this.queueName) && this.exchangeType != null) {
            this.binder = new RabbitMQBinder(this.connectionFactory);
            this.binder.binding(this.exchangeName,this.routingKey,this.queueName,this.exchangeType);
        }
    }

    public void publish(String exchangeName, String routingKey,Object message) {
        this.rabbitTemplate.convertAndSend(exchangeName,routingKey,message);
    }

    public void publish(String routingKey,Object message) {
        this.rabbitTemplate.convertAndSend(this.exchangeName,routingKey,message);
    }

    public void publish(Object message) {
        this.rabbitTemplate.convertAndSend(this.exchangeName,null,message);
    }
    public void publish(Object message, RabbitTemplate.ReturnCallback returnCallback) {
        this.rabbitTemplate.setReturnCallback(returnCallback);
        this.rabbitTemplate.convertAndSend(this.exchangeName,null,message);
    }
    public void publish(Object message, RabbitTemplate.ConfirmCallback confirmCallback) {
        this.rabbitTemplate.setConfirmCallback(confirmCallback);
        this.rabbitTemplate.convertAndSend(this.exchangeName,null,message);
    }

    public void publish(Object message, RabbitTemplate.ConfirmCallback confirmCallback,RabbitTemplate.ReturnCallback returnCallback) {
        this.rabbitTemplate.setConfirmCallback(confirmCallback);
        this.rabbitTemplate.setReturnCallback(returnCallback);
        this.rabbitTemplate.convertAndSend(this.exchangeName,null,message);
    }
}
