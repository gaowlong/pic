package com.mq;

import org.springframework.amqp.rabbit.connection.ConnectionFactory;

/**
 * Created by Gao.WenLong on 2019/9/10.
 */
public class RabbitMQFactory {

    private static ConnectionFactory connectionFactory;

    public RabbitMQFactory(ConnectionFactory connectionFactory) {
        RabbitMQFactory.connectionFactory = connectionFactory;
    }

    private static RabbitMQProducer producer(ConnectionFactory connectionFactory, String exchangeName, String routingKey, String queueName, String exchangeType) {
        RabbitMQProducer rabbitMQProducer = new RabbitMQProducer(connectionFactory, exchangeName, routingKey, queueName, exchangeType);
        rabbitMQProducer.build();
        return rabbitMQProducer;
    }

    public static RabbitMQProducer producer(String exchangeName, String routingKey, String queueName, String exchangeType) {
        return producer(connectionFactory,exchangeName,routingKey,queueName,exchangeType);
    }

    public static RabbitMQProducer directProducer(String exchangeName, String routingKey, String queueName) {
        return producer(connectionFactory,exchangeName,routingKey,queueName,ExchangeType.DIRECT);
    }

    public static RabbitMQProducer topicProducer(String exchangeName, String routingKey, String queueName) {
        return producer(connectionFactory,exchangeName,routingKey,queueName,ExchangeType.TOPIC);
    }

    public static RabbitMQProducer fanoutProducer(String exchangeName,String queueName) {
        return producer(connectionFactory,exchangeName,null,queueName,ExchangeType.FANOUT);
    }

    public static RabbitMQConsumer consumer(String queueName,RabbitMQListener rabbitMQListener) {
        return new RabbitMQConsumer(connectionFactory,queueName,rabbitMQListener);
    }

}



